package com.techlabs.dbConnect.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum StatusType {

	ACTIVE,
	INACTIVE
	
}
